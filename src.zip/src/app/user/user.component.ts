
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Component, OnInit} from '@angular/core';
import { Router } from "@angular/router";
import { UserService } from "../service/user.service";
import { User } from "../model/user.model";
import { FormBuilder} from "@angular/forms";


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  users: User[];
  constructor(public bsModalRef: BsModalRef, private formBuilder: FormBuilder, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.userService.getUsers()
      .subscribe(data => {
        this.users = data;
      });
  }

  getAllUsers() {
    this.userService.getUsers()
      .subscribe(data => {
        this.users = data;
      });
  }

  selectUser(user: User): void {
    localStorage.setItem("useridSelect", user.userId.toString());
    localStorage.setItem("userNameSelect", user.firstName);
    document.getElementById("managerid")["value"] = user.firstName;
    this.bsModalRef.hide();
  };



}