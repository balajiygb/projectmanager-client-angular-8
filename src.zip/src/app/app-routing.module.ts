import { NgModule } from '@angular/core';
import { Route, RouterModule } from '@angular/router';

import { ProjectComponent } from './project/project.component';
import { TaskComponent } from './task/task.component';
import { ListTaskComponent } from './list-task/list-task.component';

import { ListUserComponent } from './list-user/list-user.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ListProjectComponent } from './list-project/list-project.component';


const routes: Route[] = [
  {path:'', component:ListUserComponent,pathMatch:'full'},
  {path:'user',component:ListUserComponent},
  {path:'project',component:ProjectComponent},
  {path:'listproject',component:ListProjectComponent},
  {path:'task',component:TaskComponent},
  {path:'viewtask',component:ListTaskComponent},
  {path:'**', component:ListUserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),ModalModule.forRoot()],
  exports: [RouterModule]
})
export class AppRoutingModule { }
