import { Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {UserService} from "../service/user.service";
import {User} from "../model/user.model";
import {ProjectService} from "../service/project.service";
import {TaskService} from "../service/task.service";
import {Project} from "../model/project.model";

import {FormBuilder, FormGroup, Validators} from "@angular/forms";

import { UserComponent } from '../user/user.component';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { Task } from '../model/task.model';
import { ParentTask } from '../model/parentTask.model';
import { ListProjectComponent } from '../list-project/list-project.component';
import { ListParentTaskComponent } from '../task/list-parent-task/list-parent-task.component';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {
  
  addForm: FormGroup;
  flag:boolean;
  users: User[];
  sortedUsers: User[];
  tasks:Task[];
  projects:Project[];
  sortedProjects:Project[];
  public searchText : string;
  modalRef: BsModalRef;
  parentTasks:ParentTask[];
  public parentTaskValue:boolean;

  constructor(private formBuilder: FormBuilder,private router: Router,private taskService: TaskService,private projectService:ProjectService , private modalService: BsModalService,private userService: UserService) { }

  ngOnInit() {

    this.addForm = this.formBuilder.group({ 
      task: ['', Validators.required],
      priority: ['', Validators.required],
      status: ['', Validators.required],
      startdt: ['', Validators.required],
      enddt: ['', Validators.required],
      userid: ['', Validators.required],
      projectId: ['', Validators.required],
      parentId:['',Validators.required,],
      parentFlag:['',Validators.required],
      taskId:['',Validators.required]
    });

    this.addForm.get('projectId').disable();
    this.addForm.get('parentId').disable();
    this.addForm.get('userid').disable();

  }

  onSubmit() {
    this.addForm.value.userid=localStorage.getItem("useridSelect");
    this.addForm.value.projectId=localStorage.getItem("projectIdSelect");
    this.addForm.value.parentId=localStorage.getItem("pTaskNameSelect");

    if(this.parentTaskValue){
      this.addForm.value.parentFlag="Y";
      this.addForm.value.priority="0";
    }else{
      this.addForm.value.parentFlag="N";
    }

     this.taskService.createTask(this.addForm.value)
       .subscribe( data => {
       });
       this.flag=false;
       localStorage.setItem("projectIdSelect","");
       localStorage.setItem("useridSelect","");
       localStorage.setItem("pTaskNameSelect","");
   }

public onParentTask(value:boolean){
    this.parentTaskValue = value;
    if(this.parentTaskValue){
      this.addForm.get('priority').disable();
      this.addForm.get('startdt').disable();
      this.addForm.get('enddt').disable();
    }else{
      this.addForm.get('priority').enable();
      this.addForm.get('startdt').enable();
      this.addForm.get('enddt').enable();
    }
}

   openUserModal() {
    this.userService.getUsers()
    .subscribe( data => {
      this.users = data;
    });
    const initialState = {
      users:this.users
    };
    this.modalRef = this.modalService.show(UserComponent,{ initialState});
  }

  openProjectModal(){
    this.projectService.getProjects()
    .subscribe( data => {
      this.projects = data;
    });
    const initialState= {
      projects:this.projects
    };
    this.modalRef = this.modalService.show(ListProjectComponent,{initialState});
  }

  openParentTaskModal(){
    this.taskService.getParentTask()
    .subscribe( data => {
      this.parentTasks = data;
    });
    const initialState= {
      parentTasks:this.parentTasks
    };
    this.modalRef = this.modalService.show(ListParentTaskComponent,{initialState});
  }
}
