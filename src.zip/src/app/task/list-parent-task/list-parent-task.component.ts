import { Component, OnInit } from '@angular/core';
import { TaskService } from '@angular/cli/bin/routing-info/src/app/service/task.service';
import { ParentTask } from '@angular/cli/bin/routing-info/src/app/model/parentTask.model';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-list-parent-task',
  templateUrl: './list-parent-task.component.html',
  styleUrls: ['./list-parent-task.component.css']
})
export class ListParentTaskComponent implements OnInit {
  parentTasks: ParentTask[];
  constructor(private taskService:TaskService,public bsModalRef: BsModalRef) { }
  ngOnInit() {
    this.taskService.getParentTask()
    .subscribe( data => {
      this.parentTasks = data;
    });
  }
  selectPTask(parentTask:ParentTask): void{
    document.getElementById("parentId")["value"]=parentTask.parentTask;
    localStorage.setItem("pTaskNameSelect", parentTask.parentTaskId.toString());
    this.bsModalRef.hide();
  }

}
