import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListParentTaskComponent } from './list-parent-task.component';

describe('ListParentTaskComponent', () => {
  let component: ListParentTaskComponent;
  let fixture: ComponentFixture<ListParentTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListParentTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListParentTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
