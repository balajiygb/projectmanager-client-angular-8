export class ParentTask {
  parentTaskId:String; 
  parentTask: string;
  }