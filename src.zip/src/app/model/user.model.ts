export class User {
    userId:String; 
    empId:String;
    firstName: string;
    lastName: string;
  }