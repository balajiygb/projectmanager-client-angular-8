export class Task {

    taskId:number; 
    task:string;
    priority: number;
    startdt: Date;
    enddt:Date;
    status:string;
    isParent:boolean;
    parentId:string;
    userid:string; 
    projectId:number; 
    parentTaskName:string;
    parentFlag:string
  }