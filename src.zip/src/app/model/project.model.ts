export class Project {
    id: number;
    projectId:string; 
    project: string;
    priority: number;
    startdt: Date;
    enddt:Date;
    status:string;
    userId:string; 
    totalTask:String;
    completedTask:string;
    userName:string;

  }