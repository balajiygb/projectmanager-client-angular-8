import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { User } from "../model/user.model";
import { ProjectService } from "../service/project.service";
import { TaskService } from "../service/task.service";
import { Project } from "../model/project.model";
import { FormGroup } from "@angular/forms";
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Task } from '../model/task.model';
import { ListProjectComponent } from '../list-project/list-project.component';
import { EditTaskComponent } from '@angular/cli/bin/routing-info/src/app/edit-task/edit-task.component';


@Component({
  selector: 'app-list-task',
  templateUrl: './list-task.component.html'
})
export class ListTaskComponent implements OnInit {

  addForm: FormGroup;
  flag: boolean;
  users: User[];
  sortedUsers: User[];
  tasks: Task[];
  projects: Project[];
  sortedTasks: Task[];
  searchText: string;
  modalRef: BsModalRef;
  projid: number;
  inputProjId: String;
  editTask: Task;

  constructor(private taskService: TaskService, private modalService: BsModalService, private projectService: ProjectService, private router: Router) { }

  ngOnInit() {

  }

  public printTask(): void {
    this.inputProjId = localStorage.getItem("projectIdSelect");
    this.taskService.getTasksByprojectid(Number(this.inputProjId))
      .subscribe(data => {
        this.tasks = data;
      });
  }

  getAllTaskBySorted(field: string) {
      this.inputProjId = localStorage.getItem("projectIdSelect");
      this.taskService.getTasksByprojectid(Number(this.inputProjId))
        .subscribe(data => {
          this.tasks = data;
          this.sortBy(field);
        });
  }

  sortBy(field: string) {
    this.users.sort((a: any, b: any) => {
      if (a[field] < b[field]) {
        return -1;
      } else if (a[field] > b[field]) {
        return 1;
      } else {
        return 0;
      }
    });
    this.sortedUsers = this.users;
  }


  openProjectModal() {
    this.projectService.getProjects()
      .subscribe(data => {
        this.projects = data;
      });
    const initialState = {
      projects: this.projects
    };
    this.modalRef = this.modalService.show(ListProjectComponent, { initialState });
  }

  endTask(task: Task): void {
    task.status = 'C';
    this.taskService.createTask(task)
      .subscribe(data => {
      });
  }

  editTaskOnModal(task: Task, listTaskComponent: ListTaskComponent) {
    this.taskService.getTaskByTaskId(task.taskId)
      .subscribe(data => {
        this.editTask = data;
      });
    const initialState = {
      editTask: task,
      listTaskComponent: listTaskComponent
    };
    this.modalRef = this.modalService.show(EditTaskComponent, { initialState });
  }
}