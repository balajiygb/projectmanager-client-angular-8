import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Task } from '../model/task.model';
import { ParentTask } from '../model/parentTask.model';

@Injectable()
export class TaskService {
  constructor(private http: HttpClient) { }
  getTaskUrl: string = 'http://localhost:8080/tasks/task';
  addTaskUrl: string = 'http://localhost:8080/tasks/addtask';
  getParentTaskUrl: string = 'http://localhost:8080/tasks/parenttask';
  getTasksbyProjIdUrl: string = 'http://localhost:8080/tasks/viewtask/projectid/';

  createTask(task: Task) {
    return this.http.post(this.addTaskUrl, task);
  }
  getTasksByprojectid(id: Number) {
    return this.http.get<Task[]>(this.getTasksbyProjIdUrl + '/' + id);
  }
  getParentTask() {
    return this.http.get<ParentTask[]>(this.getParentTaskUrl);
  }
  getTaskByTaskId(id: number) {
    return this.http.get<Task>(this.getTaskUrl + '/' + id);
  }
}
