import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {User} from "../model/user.model";

import {Project} from "../model/project.model";
@Injectable()
export class ProjectService {
  constructor(private http: HttpClient) { }
  getAllProjectUrl : string='http://localhost:8080/projects/projectwithtask';
  addProjectUrl : string='http://localhost:8080/projects/addproject';
  delProjectUrl : string='http://localhost:8080/projects/deleteproject';

  getProjects() {
    return this.http.get<Project[]>(this.getAllProjectUrl);
  }
  createProject(project: Project) {
    return this.http.post(this.addProjectUrl, project);
  }
  deleteProj(project: Project ){
    return this.http.post(this.delProjectUrl, project);
  }
}
