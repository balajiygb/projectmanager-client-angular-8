import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from "../model/user.model";

@Injectable()
export class UserService {
  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:8080/users/';
  getAllUserUrl: string = 'http://localhost:8080/users/user';
  addUserUrl: string = 'http://localhost:8080/users/adduser';
  delUserUrl: string = 'http://localhost:8080/users/deleteuser';
  getUserbyProjIdUrl: string = 'http://localhost:8080/users/user/projectid';

  getUsers() {
    return this.http.get<User[]>(this.getAllUserUrl);
  }

  getUserById(id: number) {
    return this.http.get<User>(this.baseUrl + '/' + id);
  }

  getUserByProjectId(id: String) {
    return this.http.get<User>(this.getUserbyProjIdUrl + '/' + id);
  }

  createUser(user: User) {
    return this.http.post(this.addUserUrl, user);
  }

  updateUser(user: User) {
    return this.http.put(this.baseUrl + '/' + user.userId, user);
  }

  deleteUser(id: number) {
    return this.http.delete(this.baseUrl + '/' + id);
  }

  deleteUserObj(user: User) {
    return this.http.post(this.delUserUrl, user);
  }
}
