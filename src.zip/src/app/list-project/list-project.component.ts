import { Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {UserService} from "../service/user.service";
import {User} from "../model/user.model";
import {ProjectService} from "../service/project.service";
import {Project} from "../model/project.model";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ListTaskComponent } from '../list-task/list-task.component';
import { TaskService } from '@angular/cli/bin/routing-info/src/app/service/task.service';

@Component({
  selector: 'app-list-project',
  templateUrl: './list-project.component.html',
  styleUrls: ['./list-project.component.css']
})
export class ListProjectComponent implements OnInit {

  users: User[];
  sortedUsers: User[];
  addForm: FormGroup;
  projects:Project[];
  sortedProjects:Project[];
  public searchText : string;
  user:User;
  modalRef:BsModalRef
  editUser:User=new User;

  constructor(private listTaskComponent:ListTaskComponent, private taskService:TaskService,private projectService:ProjectService,private modalService: BsModalService,public bsModalRef: BsModalRef,private formBuilder: FormBuilder,private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.projectService.getProjects()
      .subscribe( data => {
       this.projects = data;
      }); 
  }

  getAllProjects() {
    this.projectService.getProjects()
      .subscribe( data => {
        this.projects = data;
      });
  }

  selectProject(project: Project): void {
  localStorage.setItem("projectIdSelect", project.projectId.toString());
  localStorage.setItem("projectNameSelect", project.project);
  document.getElementById("projectId")["value"]=project.project;
  this.bsModalRef.hide();
  };
}
