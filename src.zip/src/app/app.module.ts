import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListUserComponent } from './list-user/list-user.component';
import { FormsModule } from '@angular/cli/bin/routing-info/node_modules/@angular/forms';
import { UserService } from './service/user.service';
import { TaskService } from './service/task.service';
import { GrdFilterPipe } from './pipe/grd-filter.pipe';
import { ListTaskComponent } from './list-task/list-task.component';
import { UserComponent } from './user/user.component';
import { ProjectComponent } from './project/project.component';
import { TaskComponent } from './task/task.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ProjectService } from './service/project.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbPaginationModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { ListProjectComponent } from './list-project/list-project.component';
import { ListParentTaskComponent } from './task/list-parent-task/list-parent-task.component';
import { EditTaskComponent } from './edit-task/edit-task.component';
import { ViewProjectComponent } from './view-project/view-project.component';

@NgModule({
  declarations: [
    AppComponent,
    ListUserComponent,
    GrdFilterPipe,
    ListTaskComponent,
    UserComponent,
    ProjectComponent,
    TaskComponent,
    ListProjectComponent,
    ListParentTaskComponent,
    EditTaskComponent,
    ViewProjectComponent
  ],
  entryComponents: [EditTaskComponent, ViewProjectComponent, UserComponent, ListParentTaskComponent, ListProjectComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ModalModule,
    BrowserAnimationsModule,
    NgbModule,
    NgbPaginationModule,
    NgbAlertModule
  ],
  providers: [UserService, ProjectService, TaskService, BsModalService, ListTaskComponent, EditTaskComponent],
  bootstrap: [AppComponent, ViewProjectComponent, UserComponent, ListProjectComponent, ListParentTaskComponent, EditTaskComponent]
})
export class AppModule { }
