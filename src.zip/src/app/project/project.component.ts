//import { Component, OnInit } from '@angular/core';

import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { UserService } from "../service/user.service";
import { User } from "../model/user.model";
import { ProjectService } from "../service/project.service";
import { Project } from "../model/project.model";

import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { UserComponent } from '../user/user.component';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';



@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {
  users: User[];
  sortedUsers: User[];
  projects: Project[];
  sortedProjects: Project[];
  public searchText: string;
  user: User;
  modalRef: BsModalRef
  editUser: User = new User;
  addForm: FormGroup;
  flag: boolean;
  priorityInput: number;
  parentTaskValue: boolean;
  constructor(private formBuilder: FormBuilder, private router: Router, private projectService: ProjectService, private modalService: BsModalService, private userService: UserService) { }
  ngOnInit() {
    this.userService.getUsers()
      .subscribe(data => {
        this.users = data;
      });

    this.projectService.getProjects()
      .subscribe(data => {
        this.projects = data;
      });

    this.addForm = this.formBuilder.group({
      project: ['', Validators.required],
      priority: ['', Validators.required],
      status: ['', Validators.required],
      startdt: ['', Validators.required],
      enddt: ['', Validators.required],
      userId: ['', Validators.required],
      userName: ['', Validators.required]
    });

    this.addForm.get('startdt').disable();
    this.addForm.get('enddt').disable();

  }

  onSubmit() {
    if (localStorage.getItem("useridSelect") == "") {
      this.addForm.value.userId = this.editUser.userId;
    } else {
      this.addForm.value.userId = localStorage.getItem("useridSelect");
    }

    this.projectService.createProject(this.addForm.value)
      .subscribe(data => {
        this.getAllProjects();
      });
    this.flag = false;
    localStorage.setItem("useridSelect", "");
  }

  getAllProjects() {
    this.projectService.getProjects()
      .subscribe(data => {
        this.projects = data;
      });
  }

  getAllProjectsBySorted(field: string) {
    this.projectService.getProjects()
      .subscribe(data1 => {
        this.projects = data1;
        this.sortBy(field);
      });
  }

  sortBy(field: string) {
    this.projects.sort((a: any, b: any) => {
      if (a[field] < b[field]) {
        return -1;
      } else if (a[field] > b[field]) {
        return 1;
      } else {
        return 0;
      }
    });
    this.sortedProjects = this.projects;
  }

  deleteProject(project: Project): void {
    this.projectService.deleteProj(project)
      .subscribe(data => {
        this.getAllProjects();
      });
  };

  deleteUserOrig(user: User): void {
    this.userService.deleteUserObj(user)
      .subscribe(data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

  editProject(project: Project): void {
    this.userService.getUserByProjectId(project.projectId)
      .subscribe(data3 => {
        this.editUser = data3;
      });
    this.addForm = this.formBuilder.group({
      project: [project.project, Validators.required],
      priority: [project.priority, Validators.required],
      status: ['', Validators.required],
      startdt: [project.startdt, Validators.required],
      enddt: [project.enddt, Validators.required],
      userId: [project.userName, Validators.required],
      projectId: [project.projectId]
    });
    this.flag = true;
  };

  openUserModal() {
    this.userService.getUsers()
      .subscribe(data => {
        this.users = data;
      });
    const initialState = {
      users: this.users
    };
    this.modalRef = this.modalService.show(UserComponent, { initialState });
  }

  public onParentTask(value: boolean) {
    this.parentTaskValue = value;
    if (!this.parentTaskValue) {
      this.addForm.get('startdt').disable();
      this.addForm.get('enddt').disable();
    } else {
      this.addForm.get('startdt').enable();
      this.addForm.get('enddt').enable();
    }
  }
}
