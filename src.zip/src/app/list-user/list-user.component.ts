import { Component, OnInit, Pipe } from '@angular/core';
import { Router } from "@angular/router";
import { UserService } from "../service/user.service";
import { User } from "../model/user.model";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})

export class ListUserComponent implements OnInit {

  users: User[];
  sortedUsers: User[];
  public searchText: string;
  addForm: FormGroup;
  flag: boolean;

  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserService) { }
  ngOnInit() {
    this.userService.getUsers()
      .subscribe(data => {
        console.log("on init in user list componet. 2.");
        this.users = data;
      });

    this.addForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      empId: ['', Validators.required]
    });

  }

  onSubmit() {
    this.userService.createUser(this.addForm.value)
      .subscribe(data => {
        this.getAllUsers();
      });
    this.flag = false;
  }

  getAllUsers() {
    this.userService.getUsers()
      .subscribe(data => {
        this.users = data;
      });
  }

  getAllUsersBySorted(field: string) {
    this.userService.getUsers()
      .subscribe(data1 => {
        this.users = data1;
        this.sortBy(field);
      });
  }

  sortBy(field: string) {
    this.users.sort((a: any, b: any) => {
      if (a[field] < b[field]) {
        return -1;
      } else if (a[field] > b[field]) {
        return 1;
      } else {
        return 0;
      }
    });
    this.sortedUsers = this.users;
  }

  deleteUser(user: User): void {
    this.userService.deleteUserObj(user)
      .subscribe(data => {
        this.getAllUsers();
      });
  };

  editUser(user: User): void {
    this.addForm = this.formBuilder.group({
      firstName: [user.firstName, Validators.required],
      lastName: [user.lastName, Validators.required],
      empId: [user.empId, Validators.required],
      userId: [user.userId]
    });
    this.flag = true;
  };

}
